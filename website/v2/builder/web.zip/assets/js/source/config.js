/*
 *  author: gejian1@lenovo.com
 *  description: 配置程序
 */
(function(){
    lenoteConfig = {
        download: {
            android: {link: 'http://susapi.lenovomm.com/adpserver/GetPackByPN?PackageName=com.lenovo.supernote&ChannelKey=null&UserKey='},
            pc: {link: 'http://susapi.lenovomm.com/adpserver/DLBIDFS?ds=24005_20541608&rt=POL'},
            ios: {link: '/download.html'}
        }
    };
})();